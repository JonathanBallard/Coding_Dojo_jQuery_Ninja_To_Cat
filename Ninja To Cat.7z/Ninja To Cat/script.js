



$('img').click(function() {
    var newPic = $(this).attr('data-alt-src');
    $(this).attr('src', newPic);
});




































